export const Table = (props) => <div {...props} />;
