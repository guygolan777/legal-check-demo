export const Button = (props) => <div {...props} />;
