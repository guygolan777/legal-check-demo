export const Card = (props) => <div {...props} />;
