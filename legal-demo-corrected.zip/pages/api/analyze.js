export default function handler(req, res) {
  const { description } = JSON.parse(req.body);
  const mockData = {
    score: "סיכוי גבוה (80-90%)",
    advice: "המקרה שלך תואם לפסיקה קודמת. יש מקום לפנות לייעוץ משפטי או להגיש תביעה.",
    similar: [
      "פס"ד 1234/20 – פיטורין ללא שימוע",
      "פס"ד 4321/22 – הפרת חוזה העסקה",
      "פס"ד 6789/19 – אפליה במקום העבודה"
    ]
  };
  res.status(200).json(mockData);
}
