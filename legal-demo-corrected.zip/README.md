
# LegalCheckDemo – דמו לבדיקה אוטומטית של סיכויי תביעה

מערכת אינטראקטיבית לדמו של כלי בינה מלאכותית שבודק את סיכויי התביעה על סמך תיאור מקרה.

---

## 🚀 הוראות הפעלה

1. **שכפול והרצת הפרויקט**:

```bash
npx create-next-app legal-check-demo
cd legal-check-demo
```

2. **העתק את הקבצים מתוך הקובץ `legal-demo.zip`** לתיקיית הפרויקט.

3. **הרץ את השרת**:

```bash
npm install
npm run dev
```

---

## 📁 מבנה קבצים עיקרי

- `/LegalCheckDemo.js` – רכיב React הראשי
- `/pages/api/analyze.js` – קובץ API מדמה תגובה מבוססת מקרה
- `/components/ui/` – רכיבים פשוטים להדמיה (`card`, `button`, `input`, וכו')

---

## 📌 הערות

- הקוד כולל שמירת היסטוריה מקומית (localStorage)
- אפשר לייצא את הבדיקות לקובץ טקסט
- אין צורך במפתח API – הכל רץ מקומית

---

✅ מתאים להעלאה מיידית ל־Vercel או Netlify
